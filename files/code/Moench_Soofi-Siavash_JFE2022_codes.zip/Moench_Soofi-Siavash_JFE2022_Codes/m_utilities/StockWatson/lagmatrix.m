function xlagmat=lagmatrix(x,p)

xlagmat=[];
for l=p
    xlagmat=[xlagmat lag(x,l)];
end

end