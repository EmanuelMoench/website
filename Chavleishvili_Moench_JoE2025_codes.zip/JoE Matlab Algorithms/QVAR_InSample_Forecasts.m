%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Preditive distributions as of Katrina disaster %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%x%
%% Read the data file and transform variables
clear
clc
close all

sheet=1;
xlsfilename = 'DisasterMacroData.xls';
[X, TEXT]   = xlsread(xlsfilename,sheet);
Headers     = TEXT(1,2:end);

  Variables = {'CD' 'ICSA' 'IP_growth' 'CPI_growth'  'Uncertainty:h=1' 'FEDFUNDS'};
Y=[];
for i = 1:size(Variables,2)
    Y = [Y,X(:,find(strcmp(Headers, Variables(i))==1))];
end
Y(:,1) = Y(:,1)/10^6;
Y(:,2) = Y(:,2)/10^6;
%% Generate dates
StartDate = datetime(1980,01,01);
EndDate   = datetime(2019,12,01);
     date = (StartDate:calmonths(1):EndDate)';
%% Remove non-environmental disasters
      s = find(year(date) == 2001 & month(date) ==  9);
 Y(s,1) = 0;
 [T, K] = size(Y);
Headers = {'CD' 'Claims' 'Growth' 'Inflation'  'Uncertainty' 'Policy rate'};
%% Folder for the figures
Fig = 'Figures';
%% Folder for regression quantiles 
addpath('QR')
%% Distribution forecasting using QVARs
% Lag order
p = 6;
%% Equidistant quantile indices
              U_Q = 0.95;
              L_Q = 0.05;
           L_Q_CD = 0.25;
   Quantile.Quant = L_Q:0.01:U_Q;
                N = length(Quantile.Quant);
            delta = (U_Q-L_Q_CD)/(N-1);
Quantile.Quant_CD = L_Q_CD:delta:U_Q;
%% Estimate and store QVAR parameters equation-by-equation
b_hat=cell(N,K);
for q = 1:N
    [b_hat{q,1},~,~,~] = QVAR(Y,Quantile.Quant_CD(q),p,1);
    for eq = 2:K
        [b_hat{q,eq},~,~,~] = QVAR(Y,Quantile.Quant(q),p,eq);
    end
end
%% Set a horizon and number of sampling iterations for distribution predictions
H=12;
n=10^(4);
%% Empirical quantiles for the fan charts
Quantile.DensityForc = 1:1:99;
%% Calculate fan charts starting from the Katrina disaster
Y_H = QVAR_Distribution_Forecasts(Y,b_hat,N,H,p,find(year(date) == 2005 & month(date) ==  8),n);
%% Empirical quantiles of the predictive values
q=zeros(H,size(Quantile.DensityForc,2));
q_m=zeros(H,1);
for h=1:H
    q(h,:)=prctile(cellfun(@(c)c(h,3),Y_H),Quantile.DensityForc);
    q_m(h,:)=mean(cellfun(@(c)c(h,3),Y_H));
end
%% Match predictive quantiles and realizations of the growth rate
Z=Y(find(year(date) == 2005 & month(date) ==  9):(find(year(date) == 2005 & month(date) ==  8)+h),3);
[ii, iii]=min(abs(Z-q)');
q_hat=[];
quant_hat=[];
for h=1:H
    q_hat=[q_hat;q(h,iii(h))];
    quant_hat=[quant_hat;Quantile.DensityForc(iii(h))];
end
%% Generate conditional mean and the bootstrap based CIs
B=10000;
b_hat_VAR=cell(1,K);
Eps=zeros(T-p,K);

for eq=1:K
    [b_hat_VAR{1,eq},~,Eps(:,eq),~] = VAR(Y,p,eq);
end
Y_forc=VAR_Forecasts(Y,b_hat_VAR,H,p,find(year(date) == 2005 & month(date) ==  8));

[Y_IP, Y_Infl]=VAR_Bootstrap(Y,b_hat_VAR,H,p,T,B,Eps,date);

CI_IP=[prctile((Y_IP-Y_forc(:,3))',5/2)',prctile((Y_IP-Y_forc(:,3))',100-5/2)'];
CI_Infl=[prctile((Y_Infl-Y_forc(:,4))',5/2)',prctile((Y_Infl-Y_forc(:,4))',100-5/2)'];
%% Plot estimates
plt=figure;
plot((0:H)', [ones(1,size(Quantile.DensityForc,2))*Y(find(year(date) == 2005 & month(date) ==  8),3);q], 'Color', 1/300*[200,200,200],'LineWidth',0.5);
hold on
f(1)=plot((0:H)', Y(find(year(date) == 2005 & month(date) ==  8):(find(year(date) == 2005 & month(date) ==  8)+h),3), 'k-*','LineWidth',2);
hold on
f(2)=plot((1:H)',q_hat, 'r--','LineWidth',2);
hold on
f(3)=plot((1:H)',Y_forc(:,3), 'b:','LineWidth',2);
hold on
f(4:5)=plot((1:H)',Y_forc(:,3)-CI_IP, 'b--','LineWidth',2);
hold off
legend([f(1) f(2) f(3)],{'Realized','Matched quantiles','Mean'}, 'Location', 'northeast');
legend boxoff 
xlabel('h', 'FontSize', 14)
ylabel('Growth', 'FontSize', 14)
title('Predictive distribution', 'FontSize', 14)
print(plt, fullfile(Fig, 'May2021Figure11.png'),'-dpng');
clear('plt')

plt=figure;
plot((0:H)',[NaN;quant_hat], 'r-*','LineWidth',2);
ylabel('%', 'FontSize', 14)
xlabel('h', 'FontSize', 14)
box on;
ylim([1 100]);
title('Informative quantiles', 'FontSize', 14)
print(plt, fullfile(Fig, 'May2021Figure12.png'),'-dpng');
clear('plt')

%% Match predictive quantiles and realizations of the Inflation rate
q=zeros(H,size(Quantile.DensityForc,2));
q_m=zeros(H,1);
for h=1:H
    q(h,:)=prctile(cellfun(@(c)c(h,4),Y_H),Quantile.DensityForc);
    q_m(h,:)=mean(cellfun(@(c)c(h,4),Y_H));
end
Z=Y(find(year(date) == 2005 & month(date) ==  9):(find(year(date) == 2005 & month(date) ==  8)+h),4);
[ii, iii]=min(abs(Z-q)');
q_hat=[];
quant_hat=[];
for h=1:H
    q_hat=[q_hat;q(h,iii(h))];
    quant_hat=[quant_hat;Quantile.DensityForc(iii(h))];
end

%% Plot estimates
plt=figure;
plot((0:H)', [ones(1,size(Quantile.DensityForc,2))*Y(find(year(date) == 2005 & month(date) ==  8),3);q], 'Color', 1/300*[200,200,200],'LineWidth',0.5);
hold on
f(1)=plot((0:H)', Y(find(year(date) == 2005 & month(date) ==  8):(find(year(date) == 2005 & month(date) ==  8)+h),4), 'k-*','LineWidth',2);
hold on
f(2)=plot((1:H)',q_hat, 'r--','LineWidth',2);
hold on
f(3)=plot((1:H)',Y_forc(:,4), 'b:','LineWidth',2);
hold on
f(4:5)=plot((1:H)',Y_forc(:,4)-CI_Infl, 'b--','LineWidth',2);
hold off
legend([f(1) f(2) f(3)],{'Realized','Matched quantiles','Mean'}, 'Location', 'northeast');
legend boxoff 
xlabel('h', 'FontSize', 14)
ylabel('Inflation', 'FontSize', 14)
title('Predictive distribution', 'FontSize', 14)
print(plt, fullfile(Fig, 'May2021Figure13.png'),'-dpng');
clear('plt')

plt=figure;
plot((0:H)',[NaN;quant_hat], 'r-*','LineWidth',2);
ylim([1 100]);
box on;
ylabel('%', 'FontSize', 14)
xlabel('h', 'FontSize', 14)
title('Informative quantiles', 'FontSize', 14)
print(plt, fullfile(Fig, 'May2021Figure14.png'),'-dpng');
clear('plt')