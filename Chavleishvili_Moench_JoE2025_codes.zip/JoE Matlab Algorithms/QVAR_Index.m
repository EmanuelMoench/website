function index=QVAR_Index(K,N)
index=0;
while sum(index==0)~=0
      index=round(rand(K,1)*N);
end
end