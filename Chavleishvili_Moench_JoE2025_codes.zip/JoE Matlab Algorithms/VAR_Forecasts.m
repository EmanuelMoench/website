function Y_forc=VAR_Forecasts(Y,b_hat_VAR,H,p,T)
K=size(Y,2);
W=Y(T,:)';
if p>1
   for lag=2:p
       W=[W;Y(T-(lag-1),:)'];
   end
end
Y_forc=zeros(H,K);
for h=1:H
    [omega,A_0,A_1]=VAR_Companion_Form(b_hat_VAR,p,K);
    phi=(eye(size(A_0))-A_0)\omega;
    Phi=(eye(size(A_0))-A_0)\A_1;
    W=phi+Phi*W;
    Y_forc(h,:)=W(1:K);
end
end