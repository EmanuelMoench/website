%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Time series plots of the disasters, inflation and industrial production%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Read the data file and transform variables
clear
clc
close all
sheet=1;
xlsfilename = 'DisasterMacroData.xls';
[X, TEXT]   = xlsread(xlsfilename,sheet);
Headers     = TEXT(1,2:end);
Variables = {'CD' 'ICSA' 'IP_growth' 'CPI_growth'  'Uncertainty:h=1' 'FEDFUNDS'};

Y=[];
for i=1:size(Variables,2)
    Y=[Y,X(:,find(strcmp(Headers, Variables(i))==1))];
end
Y(:,1)=Y(:,1)/10^6;
Y(:,2)=Y(:,2)/10^6;

% Generate the dates
StartDate = datetime(1980,01,01);
EndDate   = datetime(2019,12,01);
date = (StartDate:calmonths(1):EndDate)';

% Remove non-environmental disasters
s = find(year(date) == 2001 & month(date) ==  9);
Y(s,1)=0;

[T, K] = size(Y);

% Folder for the figures
Fig = 'Figures';
Headers = {'CD' 'Claims' 'Growth' 'Inflation'  'Uncertainty' 'Policy rate'};

%% CD series plot
plt=figure('Position', get(0, 'Screensize'));
plot(date,Y(:, 1),'k','LineWidth',2);
datetick('x', 'yyyy')
axis tight; box on;
text(-0.08,2000,'\leftarrow Katrina', 'Color', 'm')
text(date(find(year(date) == 2000 & month(date) ==  8)),0.08,'Katrina \rightarrow', 'Color', 'r', 'FontSize', 24)
text(date(find(year(date) == 2008 & month(date) ==  1)),0.06,'Sandy \rightarrow', 'Color', 'r', 'FontSize', 24)
text(date(find(year(date) == 2007 & month(date) ==  1)),0.1,'Harvey/Irma/Maria \rightarrow', 'Color', 'r', 'FontSize', 24)
title('Time series plot','fontsize',24)
print(plt, fullfile(Fig, 'MayFigure0.png'),'-dpng');
clear('plt')

%% Interactive plots of CD, inflation and growth 
SetofPlots=[find(strcmp(Headers, 'Growth')==1) find(strcmp(Headers, 'Inflation')==1)];

% Define axis limits for Growth and inflation 
bounds=[-2 2;-0.6 1.4];

% Plot for Katrina
d_1=[find(year(date) == 2005 & month(date) ==  1):find(year(date) == 2006 & month(date) ==  12)];

for i=1:size(SetofPlots,2)
    plt=figure;
    ax = gca;
    yyaxis left
    ax.YColor = 'r';
    f=plot(date(d_1), Y(d_1, SetofPlots(i)),'r-*','LineWidth',2);
    hold on
    plot(date(d_1), ones(size(d_1,2),1)*mean(Y(:, SetofPlots(i))),'b-','LineWidth',1);
    hold on
    ylabel(Headers(SetofPlots(i)), 'FontSize', 24)
    ylim(bounds(i,:))
    yyaxis right
    ax.YColor = 'k';
    title('Katrina', 'FontSize', 24)
    plot(date(d_1), Y(d_1, 1),'k-*','LineWidth',2);
    ylabel('CD', 'FontSize', 24)
    ylim([0 0.18]) 
    hold off
    print(plt, fullfile(Fig, sprintf('May2021Figure01%d.png',i)),'-dpng');
    clear('plt')
end
%% Generate the QQ plot of the CD
plt=figure;
f=qqplot(Y(:,1));
ylabel('Quantiles of the CD')
xlabel('Quantiles of the standard normal')
title('QQ plot of the CD vs. Standard Normal')
legend([f(1)],["CD"], 'Location', 'northwest', 'FontSize', 14);
legend boxoff
print(plt, fullfile(Fig, 'QQCD'),'-dpng');
clear('plt')
