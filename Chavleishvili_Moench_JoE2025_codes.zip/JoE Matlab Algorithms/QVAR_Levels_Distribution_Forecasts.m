%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Distribution forecasts for levels%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Read the data file and transform variables
clear
clc
close all
sheet=1;
xlsfilename = 'DisasterMacroData.xls';
[X, TEXT]   = xlsread(xlsfilename,sheet);
Headers     = TEXT(1,2:end);

Variables = {'CD' 'ICSA' 'IP_growth' 'CPI_growth'  'Uncertainty:h=1' 'FEDFUNDS'};
Y=[];
for i=1:size(Variables,2)
    Y=[Y,X(:,find(strcmp(Headers, Variables(i))==1))];
end
Y(:,1)=Y(:,1)/10^6;
Y(:,2)=Y(:,2)/10^6;
%% Define levels
Variables_levels = {'IP_level' 'CPI_level'};

Y_levels=[];
for i=1:size(Variables_levels,2)
    Y_levels=[Y_levels,X(:,find(strcmp(Headers, Variables_levels(i))==1))];
end

% Generate dates
StartDate = datetime(1980,01,01);
EndDate   = datetime(2019,12,01);
date = (StartDate:calmonths(1):EndDate)';

% Remove non-environmental disasters
s = find(year(date) == 2001 & month(date) ==  9);
Y(s,1)=0;

[T, K] = size(Y);

%Folder for the figures
Fig = 'Figures';

% QR algorithms
addpath('QR')

p=6;
%Equidistant quantile indices
U_Q=0.95;
L_Q=0.05;
L_Q_CD=0.25;
U_Q_CD=0.95;
Quantile.Quant = L_Q:0.01:U_Q;
N = length(Quantile.Quant);
delta=(U_Q_CD-L_Q_CD)/(N-1);
Quantile.Quant_CD =L_Q_CD:delta:U_Q_CD;

%Estimate QVAR parameters equation-by-equation
b_hat=cell(N,K);
for q=1:N
    [b_hat{q,1},~,~,~] = QVAR(Y,Quantile.Quant_CD(q),p,1);
    for eq=2:K
        [b_hat{q,eq},~,~,~] = QVAR(Y,Quantile.Quant(q),p,eq);
    end
end
%% Factual and counterfactual predictive distributions

% Define shocks 
sigma = std(Y);
Shock = zeros(K,1);
Shock(1,1) = 9*sigma(1);

% Define forecast environment  
H=12;
n=10^5;

% Simulate out-of-sample values 
Y_H = QVAR_Distribution_Forecasts(Y,b_hat,N,H,p,T,n);
Y_H_shock =Cond_QVAR_Distribution_Forecasts(Y,b_hat,N,H,p,T,n,Shock);

Y_trend_forc=log(Y_levels(:,1).*ones(T,n));
Y_trend_forc_Shock=log(Y_levels(:,1).*ones(T,n));

%% Calculate empirical quantiles for IP
for h=1:H
    Y_trend_forc=[Y_trend_forc;(cellfun(@(c)c(h,3),Y_H)./100)'+Y_trend_forc(end,:)];
    Y_trend_forc_Shock=[Y_trend_forc_Shock;(cellfun(@(c)c(h,3),Y_H_shock)./100)'+Y_trend_forc_Shock(end,:)];
end

Quantile.DensityForc = 1:1:99;

[~,j5]=min(abs(Quantile.DensityForc-5));
[~,j50]=min(abs(Quantile.DensityForc-50));
[~,j95]=min(abs(Quantile.DensityForc-95));


plt=figure('Position', get(0, 'Screensize'));
subplot(1,2,1)
set(subplot(1,2,1), 'Position', [0.07, 0.25, 0.5, 0.5])
plot(date,(Y_levels(:,1)) , 'Color', 'b','LineWidth',1);
grid on
ylim([40 130])
set(gca, 'box', 'off')
subplot(1,2,2)
set(subplot(1,2,2), 'Position', [0.57, 0.25, 0.2, 0.5])
f(1:3)=plot((0:H)',prctile(exp(Y_trend_forc_Shock((end-H):end,:)'),[1 50 99]), 'r--','LineWidth',1);
hold on
f(4:6)=plot((0:H)',prctile(exp(Y_trend_forc((end-H):end,:)'),[1 50 99]), 'b:','LineWidth',1);
hold off
ax1 = gca;
set(gca, 'box', 'off')
set(gca, 'YTick', []);
ax1.YAxis.Visible = 'off'; 
ylim([40 130])
xl = xlim(); 
line([xl(1), xl(1)], ylim, 'color', 'k', 'LineStyle', '--');
legend([f(1),f(4)],{'Counterfactual','Factual'}, 'Location', 'southeast');
legend boxoff
xlabel('h')
sgtitle('Predictive distribution,industrial production', 'FontSize', 14) 
print(plt, fullfile(Fig, 'LevelIpMerged'),'-dpng');
clear('plt')
%% Calculate empirical quantiles for Inflation
Y_trend_forc=log(Y_levels(:,2).*ones(T,n));
Y_trend_forc_Shock=log(Y_levels(:,2).*ones(T,n));

for h=1:H
    Y_trend_forc=[Y_trend_forc;(cellfun(@(c)c(h,4),Y_H)./100)'+Y_trend_forc(end,:)];
    Y_trend_forc_Shock=[Y_trend_forc_Shock;(cellfun(@(c)c(h,4),Y_H_shock)./100)'+Y_trend_forc_Shock(end,:)];
end

plt=figure('Position', get(0, 'Screensize'));
subplot(1,2,1)
set(subplot(1,2,1), 'Position', [0.07, 0.25, 0.5, 0.6])
plot(date,(Y_levels(:,2)) , 'Color', 'b','LineWidth',1);
grid on
ylim([150 300])
set(gca, 'box', 'off')
subplot(1,2,2)
set(subplot(1,2,2), 'Position', [0.57, 0.25, 0.2, 0.6])
f(1:3)=plot((0:H)',prctile(exp(Y_trend_forc_Shock((end-H):end,:)'),[1 50 99]), 'r--','LineWidth',1);
hold on
f(4:6)=plot((0:H)',prctile(exp(Y_trend_forc((end-H):end,:)'),[1 50 99]), 'b:','LineWidth',1);
hold off
ax1 = gca;
set(gca, 'box', 'off')
set(gca, 'YTick', []);
ax1.YAxis.Visible = 'off'; 
ylim([150 300])
xl = xlim(); 
line([xl(1), xl(1)], ylim, 'color', 'k', 'LineStyle', '--');
legend([f(1),f(4)],{'Counterfactual','Factual'}, 'Location', 'southeast');
legend boxoff
xlabel('h')
sgtitle('Predictive distribution,prices', 'FontSize', 14) 
print(plt, fullfile(Fig, 'LevelInflMerged'),'-dpng');
clear('plt')
