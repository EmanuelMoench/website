function Y_H=Cond_QVAR_Distribution_Forecasts(Y,b_hat,N,H,p,T,n,Shock)
rng(2)
J=find(Shock~=0);
K=size(Y,2);
Y_H=cell(n,1);
for i=1:n
    W=Y(T,:)';
    if p>1
       for lag=2:p
           W=[W;Y(T-lag+1,:)'];
       end
    end
    Y_forc=zeros(H,K);
    [omega, A_0, A_1]=QVAR_Companion_Form(b_hat,p,K,QVAR_Index(K,N));
    phi=(eye(size(A_0))-A_0)\omega;
    Phi=(eye(size(A_0))-A_0)\A_1;
    X=W;
    W=phi+Phi*W;
    W(J)=Shock(J);
    for k=J+1:K
        W(k)=omega(k)+A_1(k,:)*X+A_0(k,1:k-1)*W(1:k-1);
    end
    Y_forc(1,:)=W(1:K);
    for h=2:H
        [omega, A_0, A_1]=QVAR_Companion_Form(b_hat,p,K,QVAR_Index(K,N));
        phi=(eye(size(A_0))-A_0)\omega;
        Phi=(eye(size(A_0))-A_0)\A_1;
        W=phi+Phi*W;
        Y_forc(h,:)=W(1:K);
    end
    Y_H{i}=Y_forc;
end
end