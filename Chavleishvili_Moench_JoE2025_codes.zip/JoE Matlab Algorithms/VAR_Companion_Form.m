function [omega,A_0,A_1]=VAR_Companion_Form(b_hat,p,K)
omega=zeros(K*p,1);
A_0=zeros(K*p,K*p);
A_1=zeros(K*p,K*p);
for eq=1:K
    b=b_hat{1,eq};
    omega(eq)=b(1);
    A_1(eq,:)=b(2:(p*K+1));
    if eq>1
       A_0(eq,1:eq-1)=b(p*K+2:(p*K+1+(eq-1)));
    end
end
if p>1
    for lag=2:p
        A_1((lag-1)*K+1:lag*K,(lag-2)*K+1:(lag-1)*K)=eye(K);
    end
end
end

