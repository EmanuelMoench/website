function [b,mu,eps,Z] = VAR(Y,p,eq)
[T,~] = size(Y);
Z = ones(T-p,1);
for j=1:p
    Z=[Z,Y((p+1-j):(end-j),:)];
end
if eq==1
   b= inv(Z'*Z)*Z'*Y((p+1):end,1);
else
    for j=1:(eq-1)
        Z=[Z,Y((p+1):end,j)];
    end 
   b= inv(Z'*Z)*Z'*Y((p+1):end,eq);
end
mu=Z*b;
eps=Y((p+1):end,eq)-mu;
end
