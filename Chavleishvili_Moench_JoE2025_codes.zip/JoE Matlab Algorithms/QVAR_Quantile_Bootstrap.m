function  Y_boot=QVAR_Quantile_Bootstrap(Y,b_hat,p,U_hat,i)
[T,K]=size(Y);
    rng(i)
W=Y(p,:)';
if p>1
   for lag=2:p
       W=[W;Y(p-(lag-1),:)'];
   end
end
Y_boot=zeros(T,K);
Y_boot(1:p,:)=Y(1:p,:);
for t=p+1:T

    I=round((T-p)*rand(1,K));
    I(I==0) = 1 ;
     
    [omega, A_0, A_1]=QVAR_Companion_Form(b_hat,p,K,U_hat(I));
    phi=(eye(size(A_0))-A_0)\omega;
    Phi=(eye(size(A_0))-A_0)\A_1;
    W=phi+Phi*W;
    Y_boot(t,:)=W(1:K)';
end
end