%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Dynamic quantile tests for QVAR specification assessment%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%x%%%%%%%%%
%% Read the data file and transform variables
clear
clc
close all
sheet=1;
xlsfilename = 'DisasterMacroData.xls';
[X, TEXT]   = xlsread(xlsfilename,sheet);
Headers     = TEXT(1,2:end);
Variables = {'CD' 'ICSA' 'IP_growth' 'CPI_growth'  'Uncertainty:h=1' 'FEDFUNDS'};
Y=[];
for i=1:size(Variables,2)
    Y=[Y,X(:,find(strcmp(Headers, Variables(i))==1))];
end
Y(:,1)=Y(:,1)/10^6;
Y(:,2)=Y(:,2)/10^6;

% Generate dates
StartDate = datetime(1980,01,01);
EndDate   = datetime(2019,12,01);
date = (StartDate:calmonths(1):EndDate)';

% Remove non-environmental disasters
s = find(year(date) == 2001 & month(date) ==  9);
Y(s,1)=0;
[T, K] = size(Y);

Headers = {'CD' 'Claims' 'Growth' 'Inflation'  'Uncertainty' 'Policy rate'};

%Folder for the figures
Fig = 'Figures';
%% Conditional quantile function plots at Katrina
addpath('QR')
p=6;
%% Quantiles for density forecasting and QIRFs
U_Q=0.95;
L_Q=0.05;
L_Q_CD=0.05;
U_Q_CD=0.95;
Quantile.Quant = L_Q:0.01:U_Q;
N = length(Quantile.Quant);
delta=(U_Q_CD-L_Q_CD)/(N-1);
Quantile.Quant_CD =L_Q_CD:delta:U_Q_CD;
%% Estimate the parameters
b_hat=cell(N,K);
for q=1:N
    [b_hat{q,1},~,~,~] = QVAR(Y,Quantile.Quant_CD(q),p,1);
    for eq=2:K
        [b_hat{q,eq},~,~,~] = QVAR(Y,Quantile.Quant(q),p,eq);
    end
end
%% Recover equation specific time-varying quantile indices
U_hat=zeros(T-p,K);
Q_hat=zeros(T-p,N);
y_fit=zeros(T-p,K);

for eq=1
    for i=1:N
        [~,Q_hat(:,i),~,~] = QVAR(Y,Quantile.Quant_CD(i),p,1);
    end 
    [~,Ind] = min(abs(Y(p+1:end,eq)-Q_hat),[],2);
    U_hat(:,eq)=Ind';
    for t=1:(T-p)
        y_fit(t,eq)=Q_hat(t,Ind(t));
    end
end

for eq=2:K
    for i=1:N
        [~,Q_hat(:,i),~,~] = QVAR(Y,Quantile.Quant(i),p,eq);
    end 
    [~,Ind] = min(abs(Y(p+1:end,eq)-Q_hat),[],2);
    U_hat(:,eq)=Ind';
    for t=1:(T-p)
        y_fit(t,eq)=Q_hat(t,Ind(t));
    end
end
%% Bootstrap 
N_boot=1000;
DQ=zeros(N,K);
for eq=1:1
    for j=1:N
        [~,q_hat,~,Z] = QVAR(Y,Quantile.Quant_CD(j),p,eq);
        h=((Y((p+1):end,eq)-q_hat)<0)-Quantile.Quant_CD(j);
        phi_hat=(Z'*Z)\(Z'*h);
        phi=[];
        for i=1:N_boot
            Y_boot=QVAR_Quantile_Bootstrap(Y,b_hat,p,U_hat,i);
            [~,Q_hat(:,j),~,Z] = QVAR(Y_boot,Quantile.Quant_CD(j),p,eq);
            h=((Y_boot((p+1):end,eq)-Q_hat(:,j))<0)-Quantile.Quant_CD(j);
            phi=[phi,(Z'*Z)\(Z'*h)];
        end
        V=(phi*phi')/N_boot;
        W=phi_hat'*inv(V)*phi_hat;
        DQ(j,eq)=1 - chi2cdf(W, size(phi_hat, 1)); 
    end
end
for eq=2:K
    for j=1:N
        [~,q_hat,~,Z] = QVAR(Y,Quantile.Quant(j),p,eq);
        h=((Y((p+1):end,eq)-q_hat)<0)-Quantile.Quant(j);
        phi_hat=(Z'*Z)\(Z'*h);
        phi=[];
        for i=1:N_boot
            Y_boot=QVAR_Quantile_Bootstrap(Y,b_hat,p,U_hat,i);
            [~,Q_hat(:,j),~,Z] = QVAR(Y_boot,Quantile.Quant(j),p,eq);
            h=((Y_boot((p+1):end,eq)-Q_hat(:,j))<0)-Quantile.Quant(j);
            phi=[phi,(Z'*Z)\(Z'*h)];
        end
        V=(phi*phi')/N_boot;
        W=phi_hat'*inv(V)*phi_hat;
        DQ(j,eq)=1 - chi2cdf(W, size(phi_hat, 1)); 
    end
end
%% Plots
Quant.plot = 0.05:0.05:0.95;
       J_i = ones(size(Quant.plot));
for i=1:size(Quant.plot,2)
    [~,J_i(i)]=min(abs(Quantile.Quant-Quant.plot(i)));
end

for i=1:K
    plt=figure;
    plot(0.05:0.05:0.95,DQ(J_i,i) ,'b-*','LineWidth',2);
    hold on
    f(1)=plot(0.05:0.05:0.95,ones(size(Quant.plot,2),1)*0.1,'k-','LineWidth',1);
    hold off
    xlabel('Quantile')
    ylim([0 1])
    title(Headers{i}, 'FontSize', 14)
    print(plt, fullfile(Fig, sprintf('DQTest%d.png',i)),'-dpng');
    clear('plt')
end