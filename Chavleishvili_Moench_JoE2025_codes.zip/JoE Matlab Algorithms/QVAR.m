function [b,q,eps,Z] = QVAR(Y,theta,p,eq)
[T,~] = size(Y);
Z = ones(T-p,1);
for j=1:p
    Z=[Z,Y((p+1-j):(end-j),:)];
end
if eq==1
   b= rq_fnm(Z, Y((p+1):end,1), theta);
else
    for j=1:(eq-1)
        Z=[Z,Y((p+1):end,j)];
    end 
   b= rq_fnm(Z, Y((p+1):end,eq), theta);
end
q=Z*b;
eps=Y((p+1):end,eq)-q;
end
