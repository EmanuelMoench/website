%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Repetitive disaster shocks:severe scenario%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Read the data file and transform variables
clear
clc
close all
sheet=1;
xlsfilename = 'DisasterMacroData.xls';
[X, TEXT]   = xlsread(xlsfilename,sheet);
Headers     = TEXT(1,2:end);

Variables = {'CD' 'ICSA' 'IP_growth' 'CPI_growth'  'Uncertainty:h=1' 'FEDFUNDS'};
Y=[];
for i=1:size(Variables,2)
    Y=[Y,X(:,find(strcmp(Headers, Variables(i))==1))];
end
Y(:,1)=Y(:,1)/10^6;
Y(:,2)=Y(:,2)/10^6;

Y_Levels=[X(:,find(strcmp(Headers, 'IP_level')==1)),X(:,find(strcmp(Headers, 'CPI_level')==1))];
%% Generate dates
StartDate = datetime(1980,01,01);
EndDate   = datetime(2019,12,01);
date = (StartDate:calmonths(1):EndDate)';
%% Remove non-environmental disasters
s = find(year(date) == 2001 & month(date) ==  9);
Y(s,1)=0;

[T, K] = size(Y);
%% Folder for the figures
Fig = 'Figures';
%% QR algorithms
addpath('QR')
%% Specify and estimate the QVAR
p=6;
%% Equidistant quantile indices
U_Q=0.95;
L_Q=0.05;
L_Q_CD=0.25;
Quantile.Quant = L_Q:0.01:U_Q;
N = length(Quantile.Quant);
delta=(0.95-L_Q_CD)/(N-1);
Quantile.Quant_CD =L_Q_CD:delta:0.95;
%% Estimate the QVAR parameters equation-by-equation
b_hat=cell(N,K);
for q=1:N
    [b_hat{q,1},~,~,~] = QVAR(Y,Quantile.Quant_CD(q),p,1);
    for eq=2:K
        [b_hat{q,eq},~,~,~] = QVAR(Y,Quantile.Quant(q),p,eq);
    end
end
%% Synthesize sequential CD shocks and calibrate distributions
H=120;
n=500;

StartDate = datetime(2020,01,01);
EndDate   = datetime(2029,12,01);
date_H = (StartDate:calmonths(1):EndDate)';

CD=Y(:,1);
CD_sorted_mild=CD(find(year(date) == 2000 & month(date) ==  1):end,1);

CD_sorted_moderate=CD(CD>prctile(CD,75));
CD_sorted_moderate=[CD_sorted_moderate;zeros(round(size(CD_sorted_moderate,1)/3),1)];

CD_sorted_severe=CD(CD>prctile(CD,90));
CD_sorted_severe=[CD_sorted_severe;zeros(round(size(CD_sorted_severe,1)/3),1)];
%% Simulate out-of-sample values
Simulated_Shocks_mild=zeros(n,H);
Simulated_Shocks_moderate=zeros(n,H);
Simulated_Shocks_severe=zeros(n,H);

IP =zeros(H,n);
Infl =zeros(H,n);

mu_IP_severe =zeros(H,n);
sigma_IP_severe =zeros(H,n);
mu_IP_moderate =zeros(H,n);
sigma_IP_moderate =zeros(H,n);
mu_IP_mild =zeros(H,n);
sigma_IP_mild =zeros(H,n);

mu_Infl_severe =zeros(H,n);
sigma_Infl_severe =zeros(H,n);
mu_Infl_moderate =zeros(H,n);
sigma_Infl_moderate =zeros(H,n);
mu_Infl_mild =zeros(H,n);
sigma_Infl_mild =zeros(H,n);

for j=1:n
    for h=1:H
        Simulated_Shocks_severe(j,h)=CD_sorted_severe(randsample(size(CD_sorted_severe,1),1));
        Simulated_Shocks_moderate(j,h)=CD_sorted_moderate(randsample(size(CD_sorted_moderate,1),1));
        Simulated_Shocks_mild(j,h)=CD_sorted_mild(randsample(size(CD_sorted_mild,1),1));
    end
end
%% Severe scenario
for j=1:n
    J=0;
    for i=1:n
        Z=Y;
        Y_H_out=zeros(H,K);
        for h=1:H
            J=J+1;
            [Y_H] = QVAR_Recursions(Z,b_hat,N,p,size(Z,1),Simulated_Shocks_severe(j,h),J);
            Z=[Z;Y_H'];
            Y_H_out(h,:)=Y_H';
        end
        IP(:,i)=Y_H_out(:,3);
        Infl(:,i)=Y_H_out(:,4);
    end
        mu_IP_severe(:,j)=mean(IP,2);
     sigma_IP_severe(:,j)=std(IP')';
      mu_Infl_severe(:,j)=mean(Infl,2);
   sigma_Infl_severe(:,j)=std(Infl')';
   sprintf('Sampling iteration # %d:Severe scenario', j)
end
%% Moderate scenario
for j=1:n
    J=0;
    for i=1:n
        Z=Y;
        Y_H_out=zeros(H,K);
        for h=1:H
            J=J+1;
            [Y_H] = QVAR_Recursions(Z,b_hat,N,p,size(Z,1),Simulated_Shocks_moderate(j,h),J);
            Z=[Z;Y_H'];
            Y_H_out(h,:)=Y_H';
        end
        IP(:,i)=Y_H_out(:,3);
        Infl(:,i)=Y_H_out(:,4);
    end
        mu_IP_moderate(:,j)=mean(IP,2);
     sigma_IP_moderate(:,j)=std(IP')';
      mu_Infl_moderate(:,j)=mean(Infl,2);
   sigma_Infl_moderate(:,j)=std(Infl')';
   sprintf('Sampling iteration # %d:Moderate scenario', j)
end
%% Mild scenario
for j=1:n
    J=0;
    for i=1:n
        Z=Y;
        Y_H_out=zeros(H,K);
        for h=1:H
            J=J+1;
            [Y_H] = QVAR_Recursions(Z,b_hat,N,p,size(Z,1),Simulated_Shocks_mild(j,h),J);
            Z=[Z;Y_H'];
            Y_H_out(h,:)=Y_H';
        end
        IP(:,i)=Y_H_out(:,3);
        Infl(:,i)=Y_H_out(:,4);
    end
        mu_IP_mild(:,j)=mean(IP,2);
     sigma_IP_mild(:,j)=std(IP')';
      mu_Infl_mild(:,j)=mean(Infl,2);
   sigma_Infl_mild(:,j)=std(Infl')';
   sprintf('Sampling iteration # %d:Mild scenario', j)
end
%%
pts_mu=-1:0.01:1;
pts_sigma=0.2:0.01:1;

for i=1:n
    [f_mu_severe(:,i),xi_mu_severe(:,i)] = ksdensity(mu_IP_severe(:,i),pts_mu);
    [f_mu_moderate(:,i),xi_mu_moderate(:,i)] = ksdensity(mu_IP_moderate(:,i),pts_mu);
    [f_mu_mild(:,i),xi_mu_mild(:,i)] = ksdensity(mu_IP_mild(:,i),pts_mu);
end

plt=figure;
f(1)=plot(pts_mu,mean(f_mu_severe,2),'-r','LineWidth',2);
hold on
f(2)=plot(pts_mu,mean(f_mu_moderate,2),'-b','LineWidth',2);
hold on
f(3)=plot(pts_mu,mean(f_mu_mild,2),'-k','LineWidth',2);
legend([f(1),f(2),f(3)],{'Severe','Moderate','Mild'})
print(plt, fullfile(Fig, 'UpdScenarioJointKernelMean'),'-dpng');
clear('plt')

for i=1:n
    [f_sigma_severe(:,i),xi_sigma_severe(:,i)] = ksdensity(sigma_IP_severe(:,i),pts_sigma);
    [f_sigma_moderate(:,i),xi_sigma_moderate(:,i)] = ksdensity(sigma_IP_moderate(:,i),pts_sigma);
    [f_sigma_mild(:,i),xi_sigma_mild(:,i)] = ksdensity(sigma_IP_mild(:,i),pts_sigma);
end

plt=figure;
f(1)=plot(pts_sigma,mean(f_sigma_severe,2),'-r','LineWidth',2);
hold on
f(2)=plot(pts_sigma,mean(f_sigma_moderate,2),'-b','LineWidth',2);
hold on
f(3)=plot(pts_sigma,mean(f_sigma_mild,2),'-k','LineWidth',2);
legend([f(1),f(2),f(3)],{'Severe','Moderate','Mild'})
print(plt, fullfile(Fig, 'UpdScenarioJointKernelSigma'),'-dpng');
clear('plt')

%% Inflation plots
pts_mu=-0.1:0.01:1;
pts_sigma=0:0.01:0.8;

for i=1:n
    [f_mu_Infl_severe(:,i),xi_mu_Infl_severe(:,i)] = ksdensity(mu_Infl_severe(:,i),pts_mu);
    [f_mu_Infl_moderate(:,i),xi_mu_Infl_moderate(:,i)] = ksdensity(mu_Infl_moderate(:,i),pts_mu);
    [f_mu_Infl_mild(:,i),xi_mu_Infl_mild(:,i)] = ksdensity(mu_Infl_mild(:,i),pts_mu);
end

plt=figure;
f(1)=plot(pts_mu,mean(f_mu_Infl_severe,2),'-r','LineWidth',2);
hold on
f(2)=plot(pts_mu,mean(f_mu_Infl_moderate,2),'-b','LineWidth',2);
hold on
f(3)=plot(pts_mu,mean(f_mu_Infl_mild,2),'-k','LineWidth',2);
legend([f(1),f(2),f(3)],{'Severe','Moderate','Mild'})
print(plt, fullfile(Fig, 'UpdScenarioJointKernelMuInfl'),'-dpng');
clear('plt')

for i=1:n
    [f_sigma_Infl_severe(:,i),xi_sigma_Infl_severe(:,i)] = ksdensity(sigma_Infl_severe(:,i),pts_sigma);
    [f_sigma_Infl_moderate(:,i),xi_sigma_Infl_moderate(:,i)] = ksdensity(sigma_Infl_moderate(:,i),pts_sigma);
    [f_sigma_Infl_mild(:,i),xi_sigma_Infl_mild(:,i)] = ksdensity(sigma_Infl_mild(:,i),pts_sigma);
end

plt=figure;
f(1)=plot(pts_sigma,mean(f_sigma_Infl_severe,2),'-r','LineWidth',2);
hold on
f(2)=plot(pts_sigma,mean(f_sigma_Infl_moderate,2),'-b','LineWidth',2);
hold on
f(3)=plot(pts_sigma,mean(f_sigma_Infl_mild,2),'-k','LineWidth',2);
legend([f(1),f(2),f(3)],{'Severe','Moderate','Mild'})
print(plt, fullfile(Fig, 'UpdScenarioJointKernelSigmaInfl'),'-dpng');
clear('plt')
%% Scatter plots
plt=figure;
ax1 = subplot(1,1,1);
scatter(ax1,mean(mu_IP_severe,1),mean(sigma_IP_severe,1),"r")
xlim([-0.12 -0.02])
ylim([0.45 0.75])
l1 = lsline(ax1);
l1.Color = 'r';
l1.LineWidth = 1;
title('Severe')
text(-0.11,0.74,sprintf('Correlation: %g', corr(mean(mu_IP_severe,1)',mean(sigma_IP_severe,1)')))
han=axes(plt,'visible','off'); 
han.XLabel.Visible='on';
han.YLabel.Visible='on';
ylabel(han,'Standard deviation');
xlabel(han,'Mean');
print(plt, fullfile(Fig, 'CorrScatterPlotIPSevere'),'-dpng');
clear('plt')


plt=figure;
ax1 = subplot(1,1,1);
scatter(ax1,mean(mu_IP_moderate,1),mean(sigma_IP_moderate,1),"b")
xlim([-0.12 -0.02])
ylim([0.45 0.75])
l1 = lsline(ax1);
l1.Color = 'b';
l1.LineWidth = 1;
title('Moderate')
text(-0.11,0.74,sprintf('Correlation: %g', corr(mean(mu_IP_moderate,1)',mean(sigma_IP_moderate,1)')))
han=axes(plt,'visible','off'); 
han.XLabel.Visible='on';
han.YLabel.Visible='on';
ylabel(han,'Standard deviation');
xlabel(han,'Mean');
print(plt, fullfile(Fig, 'CorrScatterPlotIPModerate'),'-dpng');
clear('plt')



plt=figure;
ax1 = subplot(1,1,1);
scatter(ax1,mean(mu_IP_mild,1),mean(sigma_IP_mild,1),"k")
xlim([-0.12 -0.02])
ylim([0.45 0.75])
l1 = lsline(ax1);
l1.Color = 'k';
l1.LineWidth = 1;
title('Mild')
text(-0.11,0.74,sprintf('Correlation: %g', corr(mean(mu_IP_mild,1)',mean(sigma_IP_mild,1)')))
han=axes(plt,'visible','off'); 
han.XLabel.Visible='on';
han.YLabel.Visible='on';
ylabel(han,'Standard deviation');
xlabel(han,'Mean');
print(plt, fullfile(Fig, 'CorrScatterPlotIPmild'),'-dpng');
clear('plt')



plt=figure;
ax1 = subplot(1,1,1);
scatter(ax1,mean(mu_Infl_severe,1),mean(sigma_Infl_severe,1),"r")
xlim([0.2 0.5])
ylim([ 0.2 0.36])
l1 = lsline(ax1);
l1.Color = 'r';
l1.LineWidth = 1;
title('Severe')
text(0.23,0.35,sprintf('Correlation: %g', corr(mean(mu_Infl_severe,1)',mean(sigma_Infl_severe,1)')))
han=axes(plt,'visible','off'); 
han.XLabel.Visible='on';
han.YLabel.Visible='on';
ylabel(han,'Standard deviation');
xlabel(han,'Mean');
print(plt, fullfile(Fig, 'CorrScatterPlotInflSevere'),'-dpng');
clear('plt')


plt=figure;
ax1 = subplot(1,1,1);
scatter(ax1,mean(mu_Infl_moderate,1),mean(sigma_Infl_moderate,1),"b")
xlim([0.2 0.5])
ylim([ 0.2 0.36])
l1 = lsline(ax1);
l1.Color = 'b';
l1.LineWidth = 1;
title('Moderate')
text(0.23,0.35,sprintf('Correlation: %g', corr(mean(mu_Infl_moderate,1)',mean(sigma_Infl_moderate,1)')))
han=axes(plt,'visible','off'); 
han.XLabel.Visible='on';
han.YLabel.Visible='on';
ylabel(han,'Standard deviation');
xlabel(han,'Mean');
print(plt, fullfile(Fig, 'CorrScatterPlotInflModerate'),'-dpng');
clear('plt')



plt=figure;
ax1 = subplot(1,1,1);
scatter(ax1,mean(mu_Infl_mild,1),mean(sigma_Infl_mild,1),"k")
xlim([0.2 0.5])
ylim([ 0.2 0.36])
l1 = lsline(ax1);
l1.Color = 'k';
l1.LineWidth = 1;
title('Mild')
text(0.23,0.35,sprintf('Correlation: %g', corr(mean(mu_Infl_mild,1)',mean(sigma_Infl_mild,1)')))
han=axes(plt,'visible','off'); 
han.XLabel.Visible='on';
han.YLabel.Visible='on';
ylabel(han,'Standard deviation');
xlabel(han,'Mean');
print(plt, fullfile(Fig, 'CorrScatterPlotInflmild'),'-dpng');
clear('plt')

