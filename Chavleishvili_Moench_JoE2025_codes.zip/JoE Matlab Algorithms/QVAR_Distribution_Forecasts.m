function Y_H=QVAR_Distribution_Forecasts(Y,b_hat,N,H,p,T,n)
rng(2);
K=size(Y,2);
Y_H=cell(n,1);
for i=1:n
    W=Y(T,:)';
    if p>1
       for lag=2:p
           W=[W;Y(T-(lag-1),:)'];
       end
    end
    Y_forc=zeros(H,K);
    for h=1:H
        [omega, A_0, A_1]=QVAR_Companion_Form(b_hat,p,K,QVAR_Index(K,N));
        phi=(eye(size(A_0))-A_0)\omega;
        Phi=(eye(size(A_0))-A_0)\A_1;
        W=phi+Phi*W;
        Y_forc(h,:)=W(1:K);
    end
    Y_H{i}=Y_forc;
end
end