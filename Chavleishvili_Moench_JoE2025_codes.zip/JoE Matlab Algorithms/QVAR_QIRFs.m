%%%%%%%%%%%%%%%%%%%%
%QIRFs for the QVAR%
%%%%%%%%%%%%%%%%%%%%
%% Read the data file and transform the variables
clear
clc
close all
sheet=1;
xlsfilename = 'DisasterMacroData.xls';
[X, TEXT]   = xlsread(xlsfilename,sheet);
Headers     = TEXT(1,2:end);

Variables = {'CD' 'ICSA' 'IP_growth' 'CPI_growth'  'Uncertainty:h=1' 'FEDFUNDS'};
Y=[];
for i=1:size(Variables,2)
    Y=[Y,X(:,find(strcmp(Headers, Variables(i))==1))];
end
Y(:,1)=Y(:,1)/10^6;
Y(:,2)=Y(:,2)/10^6;

% Generate dates
StartDate = datetime(1980,01,01);
EndDate   = datetime(2019,12,01);
date = (StartDate:calmonths(1):EndDate)';

% Remove non-environmental disasters
s = find(year(date) == 2001 & month(date) ==  9);
Y(s,1)=0;

[T, K] = size(Y);

Headers = {'CD' 'Claims' 'Growth' 'Inflation'  'Uncertainty' 'Policy rate'};

% Folder for the figures
Fig = 'Figures';
% QR algorithms
addpath('QR')

%% Specify and estimate the QVAR
p=6;
% Specify an equidistant grid of the quantile indices
U_Q=0.95;
L_Q=0.05;
L_Q_CD=0.25;
Quantile.Quant = L_Q:0.01:U_Q;
N = length(Quantile.Quant);
delta=(U_Q-L_Q_CD)/(N-1);
Quantile.Quant_CD =L_Q_CD:delta:U_Q;

% Estimate the QVAR parameters equation-by-equation
b_hat=cell(N,K);
for q=1:N
    [b_hat{q,1},~,~,~] = QVAR(Y,Quantile.Quant_CD(q),p,1);
    for eq=2:K
        [b_hat{q,eq},~,~,~] = QVAR(Y,Quantile.Quant(q),p,eq);
    end
end
%% Specify and construct QIRFs
% Specify horizon, sampling and poinbt in time
H=12;
n=10^(5);
t=T;

% Define the CD shock
sigma = std(Y);
Shock = zeros(K,1);
Shock(1,1) = 9*sigma(1);

% Simulate out-of-sample values through the sampling algorithm 1
Y_H = QVAR_Distribution_Forecasts(Y,b_hat,N,H,p,t,n);
Y_H_shock =Cond_QVAR_Distribution_Forecasts(Y,b_hat,N,H,p,T,n,Shock);
%% QIRFs
QIRF=cell(1,2);
Quantile.QIRFs = [1 5 50 95 99];
% Define the subsampling environment
psai=2/5;
Kappa=5;
n_sub=round(Kappa*n^(psai));
B=10000;

%% Calculate QIRFs for the IP
Y_sub=cell(n_sub,1);
Y_sub_shock=cell(n_sub,1);
q_shock =cell(1,B);
q =cell(1,B);
for j=1:B
        Draw=round(rand(n_sub,1)*n);
        Draw(Draw<= 0) = 1;
        Draw_shock=round(rand(n_sub,1)*n);
        Draw_shock(Draw_shock<= 0) = 1;
    for i=1:n_sub
        Y_sub{i}=Y_H{Draw(i)};
        Y_sub_shock{i}=Y_H_shock{Draw_shock(i)};
    end
    for h=1:H
        q{j}(h,:)=prctile(cellfun(@(c)c(h,3),Y_sub),Quantile.QIRFs);
        q_shock{j}(h,:)=prctile(cellfun(@(c)c(h,3),Y_sub_shock),Quantile.QIRFs);
    end
    QIRF{j}=q_shock{j}-q{j};
    sprintf('Subsampling iteration %d', j)
end
q=zeros(H,size(Quantile.QIRFs,2));
q_shock =zeros(H,size(Quantile.QIRFs,2));
for h=1:H
    q(h,:)=prctile(cellfun(@(c)c(h,3),Y_H),Quantile.QIRFs);
    q_shock(h,:)=prctile(cellfun(@(c)c(h,3),Y_H_shock),Quantile.QIRFs);
end
QIRF_point=q_shock-q;

% Calculate CIs at alpha confidence level
sigma_hat=cell(1,size(Quantile.QIRFs,2));
alpha=1;
for h=1:H
    for j=1:size(Quantile.QIRFs,2)
        sigma_hat{j}(h,1)=prctile(cellfun(@(c)c(h,j),QIRF)-QIRF_point(h,j),alpha/2);
        sigma_hat{j}(h,2)=prctile(cellfun(@(c)c(h,j),QIRF)-QIRF_point(h,j),100-alpha/2);
    end
end

Headers = {'1%' '5%' '50%' '95%' '99%'};

% Plot QIRFs
for i=1:size(Quantile.QIRFs,2)
    plt=figure;
    f(1)=plot((1:H)',QIRF_point(:,i) , '--','LineWidth',2,'Color','b');
    hold on
    f(2:3)=plot((1:H)', QIRF_point(:,i)-sigma_hat{i},'b:','LineWidth',1.5);
    hold on
    plot(1:h,zeros(h,1),'r-','LineWidth',0.5);
    hold off
    xlabel('h')
    grid on
    ylim([-2 1.2]) 
    legend([f(1)],[Headers{i}], 'Location', 'southeast', 'FontSize', 14);
    title('Quantile IRFs, IP growth', 'FontSize', 14)
    legend boxoff
    print(plt, fullfile(Fig, sprintf('SamplingQIRFIp%d.png',i)),'-dpng');
    clear('plt')
end

%% Calculate QIRFs for the Inflation
Y_sub=cell(n_sub,1);
Y_sub_shock=cell(n_sub,1);
q_shock =cell(1,B);
q =cell(1,B);
for j=1:B
        Draw=round(rand(n_sub,1)*n);
        Draw(Draw<= 0) = 1;
        Draw_shock=round(rand(n_sub,1)*n);
        Draw_shock(Draw_shock<= 0) = 1;
    for i=1:n_sub
        Y_sub{i}=Y_H{Draw(i)};
        Y_sub_shock{i}=Y_H_shock{Draw_shock(i)};
    end
    for h=1:H
        q{j}(h,:)=prctile(cellfun(@(c)c(h,4),Y_sub),Quantile.QIRFs);
        q_shock{j}(h,:)=prctile(cellfun(@(c)c(h,4),Y_sub_shock),Quantile.QIRFs);
    end
    QIRF{j}=q_shock{j}-q{j};
    sprintf('Subsampling iteration %d', j)
end
q=zeros(H,size(Quantile.QIRFs,2));
q_shock =zeros(H,size(Quantile.QIRFs,2));
for h=1:H
    q(h,:)=prctile(cellfun(@(c)c(h,4),Y_H),Quantile.QIRFs);
    q_shock(h,:)=prctile(cellfun(@(c)c(h,4),Y_H_shock),Quantile.QIRFs);
end
QIRF_point=q_shock-q;

% Calculate CIs at alpha confidence level
sigma_hat=cell(1,size(Quantile.QIRFs,2));
alpha=1;
for h=1:H
    for j=1:size(Quantile.QIRFs,2)
        sigma_hat{j}(h,1)=prctile(cellfun(@(c)c(h,j),QIRF)-QIRF_point(h,j),alpha/2);
        sigma_hat{j}(h,2)=prctile(cellfun(@(c)c(h,j),QIRF)-QIRF_point(h,j),100-alpha/2);
    end
end

Headers = {'1%' '5%' '50%' '95%' '99%'};

% Plot QIRFs
for i=1:size(Quantile.QIRFs,2)
    plt=figure;
    f(1)=plot((1:H)',QIRF_point(:,i) , '--','LineWidth',2,'Color','b');
    hold on
    f(2:3)=plot((1:H)', QIRF_point(:,i)-sigma_hat{i},'b:','LineWidth',1.5);
    hold on
    plot(1:h,zeros(h,1),'r-','LineWidth',0.5);
    hold off
    xlabel('h')
    grid on
    ylim([-2 1.2]) 
    legend([f(1)],[Headers{i}], 'Location', 'southeast', 'FontSize', 14);
    title('Quantile IRFs, Inflation', 'FontSize', 14)
    legend boxoff
    print(plt, fullfile(Fig, sprintf('SamplingQIRFInfl%d.png',i)),'-dpng');
    clear('plt')
end
