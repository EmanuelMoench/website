%%%%%%%%%%%%%%%%%%%%%%
%FAN charts for QIRFs%
%%%%%%%%%%%%%%%%%%%%%%
%% Read the data file and transform variables
clear
clc
close all
sheet=1;
xlsfilename = 'DisasterMacroData.xls';
[X, TEXT]   = xlsread(xlsfilename,sheet);
Headers     = TEXT(1,2:end);

Variables = {'CD' 'ICSA' 'IP_growth' 'CPI_growth'  'Uncertainty:h=1' 'FEDFUNDS'};
Y=[];
for i=1:size(Variables,2)
    Y=[Y,X(:,find(strcmp(Headers, Variables(i))==1))];
end
Y(:,1)=Y(:,1)/10^6;
Y(:,2)=Y(:,2)/10^6;

%% Generate dates
StartDate = datetime(1980,01,01);
EndDate   = datetime(2019,12,01);
date = (StartDate:calmonths(1):EndDate)';

%% Remove non-environmental disasters
s = find(year(date) == 2001 & month(date) ==  9);
Y(s,1)=0;

[T, K] = size(Y);

%% Folder for the figures
Fig = 'Figures';
%% QR algorithms
addpath('QR')
%% Specify and estimate the QVAR
p=6;
%% Equidistant quantile indices
U_Q=0.95;
L_Q=0.05;
L_Q_CD=0.25;
Quantile.Quant = L_Q:0.01:U_Q;
N = length(Quantile.Quant);
delta=(U_Q-L_Q_CD)/(N-1);
Quantile.Quant_CD =L_Q_CD:delta:U_Q;

%% Estimate the QVAR parameters equation-by-equation
b_hat=cell(N,K);
for q=1:N
    [b_hat{q,1},~,~,~] = QVAR(Y,Quantile.Quant_CD(q),p,1);
    for eq=2:K
        [b_hat{q,eq},~,~,~] = QVAR(Y,Quantile.Quant(q),p,eq);
    end
end

%% QIRFs
% Define shocks 
sigma = std(Y);
Shock = zeros(K,1);
Shock(1,1) = 9*sigma(1);

H=12;
t=T;
n=10^5;

%% Simulate out-of-sample values and calculate QIRFs
Y_H = QVAR_Distribution_Forecasts(Y,b_hat,N,H,p,t,n);
Y_H_shock =Cond_QVAR_Distribution_Forecasts(Y,b_hat,N,H,p,T,n,Shock);

Quantile.DensityForc = 1:1:99;

[~,j1]=min(abs(Quantile.DensityForc-1));
[~,j5]=min(abs(Quantile.DensityForc-5));
[~,j50]=min(abs(Quantile.DensityForc-50));
[~,j95]=min(abs(Quantile.DensityForc-95));
[~,j99]=min(abs(Quantile.DensityForc-99));
N=size(Quantile.DensityForc,2);
%% Plots for IP growth
q=zeros(H,N);
q_shock =zeros(H,N);
for h=1:H
    q(h,:)=prctile(cellfun(@(c)c(h,3),Y_H),Quantile.DensityForc);
    q_shock(h,:)=prctile(cellfun(@(c)c(h,3),Y_H_shock),Quantile.DensityForc);
end
QIRF_point_shock=[Y(T,3).*ones(1,N);q_shock];
QIRF_point=[Y(T,3).*ones(1,N);q];


%% Plot fan charts
plt=figure;
plot((0:H)', QIRF_point_shock, 'Color', 1/300*[200,200,200],'LineWidth',0.5);
hold on
f(1)=plot((0:H)', QIRF_point_shock(:,[j1]), '-s','LineWidth',2,'Color','k');
hold on
f(2)=plot((0:H)', QIRF_point_shock(:,[j5]), '-d','LineWidth',2,'Color','k');
hold on
f(3)=plot((0:H)', QIRF_point_shock(:,[j50]), 'r-o','LineWidth',2);
hold on
f(4)=plot((0:H)', QIRF_point_shock(:,[j95]), 'b-*','LineWidth',2);
hold on
f(5)=plot((0:H)', QIRF_point_shock(:,[j99]), 'p-','LineWidth',2,'Color','b');
hold off
legend([f(1), f(2), f(3), f(4), f(5)],[{'1%'},{'5%'},{' 50%'},{'95%'},{'99%'}], 'Location', 'southeast');
legend boxoff
ylim([-4 2])
grid on
title('Counterfactual predictive distribution', 'FontSize', 14)
xlabel('h', 'FontSize', 14)
ylabel('Growth', 'FontSize', 14)
print(plt, fullfile(Fig, 'QIRFIp01'),'-dpng');
clear('plt')

plt=figure;
plot((0:H)', QIRF_point, 'Color', 1/300*[200,200,200],'LineWidth',0.5);
hold on
f(1)=plot((0:H)', QIRF_point(:,[j1]), '-s','LineWidth',2,'Color','k');
hold on
f(2)=plot((0:H)', QIRF_point(:,[j5]), '-d','LineWidth',2,'Color','k');
hold on
f(3)=plot((0:H)', QIRF_point(:,[j50]), 'r-o','LineWidth',2);
hold on
f(4)=plot((0:H)', QIRF_point(:,[j95]), 'b-*','LineWidth',2);
hold on
f(5)=plot((0:H)', QIRF_point(:,[j99]), 'p-','LineWidth',2,'Color','b');
hold off
legend([f(1), f(2), f(3), f(4), f(5)],[{'1%'},{'5%'},{' 50%'},{'95%'},{'99%'}], 'Location', 'southeast');
legend boxoff
ylim([-4 2])
grid on
title('Factual predictive distribution', 'FontSize', 14)
xlabel('h', 'FontSize', 14)
ylabel('Growth', 'FontSize', 14)
print(plt, fullfile(Fig, 'QIRFIp02'),'-dpng');
clear('plt')

%% Plot fan charts
plt=figure;
f(1)=plot((0:H)', QIRF_point_shock(:,[j1])-QIRF_point(:,[j1]), '-s','LineWidth',2,'Color','k');
hold on
f(2)=plot((0:H)', QIRF_point_shock(:,[j5])-QIRF_point(:,[j5]), '-d','LineWidth',2,'Color','k');
hold on
f(3)=plot((0:H)', QIRF_point_shock(:,[j50])-QIRF_point(:,[j50]), 'r-o','LineWidth',2);
hold on
f(4)=plot((0:H)', QIRF_point_shock(:,[j95])-QIRF_point(:,[j95]), 'b-*','LineWidth',2);
hold on
f(5)=plot((0:H)', QIRF_point_shock(:,[j99])-QIRF_point(:,[j99]), 'p-','LineWidth',2,'Color','b');
hold off
legend([f(1), f(2), f(3), f(4), f(5)],[{'1%'},{'5%'},{' 50%'},{'95%'},{'99%'}], 'Location', 'southeast');
legend boxoff
ylim([-1 1])
grid on
title('Difference', 'FontSize', 14)
xlabel('h', 'FontSize', 14)
ylabel('Growth', 'FontSize', 14)
print(plt, fullfile(Fig, 'QIRFIp03'),'-dpng');
clear('plt')

%% Plots for Inflation
q=zeros(H,size(Quantile.DensityForc,2));
q_shock =zeros(H,size(Quantile.DensityForc,2));
for h=1:H
    q(h,:)=prctile(cellfun(@(c)c(h,4),Y_H),Quantile.DensityForc);
    q_shock(h,:)=prctile(cellfun(@(c)c(h,4),Y_H_shock),Quantile.DensityForc);
end
QIRF_point_shock=[Y(T,4).*ones(1,N);q_shock];
QIRF_point=[Y(T,4).*ones(1,N);q];

%% Plot fan charts
plt=figure;
plot((0:H)', QIRF_point_shock, 'Color', 1/300*[200,200,200],'LineWidth',0.5);
hold on
f(1)=plot((0:H)', QIRF_point_shock(:,[j1]), '-s','LineWidth',2,'Color','k');
hold on
f(2)=plot((0:H)', QIRF_point_shock(:,[j5]), '-d','LineWidth',2,'Color','k');
hold on
f(3)=plot((0:H)', QIRF_point_shock(:,[j50]), 'r-o','LineWidth',2);
hold on
f(4)=plot((0:H)', QIRF_point_shock(:,[j95]), 'b-*','LineWidth',2);
hold on
f(5)=plot((0:H)', QIRF_point_shock(:,[j99]), 'p-','LineWidth',2,'Color','b');
hold off
legend([f(1), f(2), f(3), f(4), f(5)],[{'1%'},{'5%'},{' 50%'},{'95%'},{'99%'}], 'Location', 'southeast');
legend boxoff
ylim([-1.5 1.5])
grid on
title('Counterfactual predictive distribution', 'FontSize', 14)
xlabel('h', 'FontSize', 14)
ylabel('Inflation', 'FontSize', 14)
print(plt, fullfile(Fig, 'QIRFInfl01'),'-dpng');
clear('plt')

plt=figure;
plot((0:H)', QIRF_point, 'Color', 1/300*[200,200,200],'LineWidth',0.5);
hold on
f(1)=plot((0:H)', QIRF_point(:,[j1]), '-s','LineWidth',2,'Color','k');
hold on
f(2)=plot((0:H)', QIRF_point(:,[j5]), '-d','LineWidth',2,'Color','k');
hold on
f(3)=plot((0:H)', QIRF_point(:,[j50]), 'r-o','LineWidth',2);
hold on
f(4)=plot((0:H)', QIRF_point(:,[j95]), 'b-*','LineWidth',2);
hold on
f(5)=plot((0:H)', QIRF_point(:,[j99]), 'p-','LineWidth',2,'Color','b');
hold off
legend([f(1), f(2), f(3), f(4), f(5)],[{'1%'},{'5%'},{' 50%'},{'95%'},{'99%'}], 'Location', 'southeast');
legend boxoff
ylim([-1.5 1.5])
grid on
title('Factual predictive distribution', 'FontSize', 14)
xlabel('h', 'FontSize', 14)
ylabel('Inflation', 'FontSize', 14)
print(plt, fullfile(Fig, 'QIRFInfl02'),'-dpng');
clear('plt')

%% Plot fan charts
plt=figure;
f(1)=plot((0:H)', QIRF_point_shock(:,[j1])-QIRF_point(:,[j1]), '-s','LineWidth',2,'Color','k');
hold on
f(2)=plot((0:H)', QIRF_point_shock(:,[j5])-QIRF_point(:,[j5]), '-d','LineWidth',2,'Color','k');
hold on
f(3)=plot((0:H)', QIRF_point_shock(:,[j50])-QIRF_point(:,[j50]), 'r-o','LineWidth',2);
hold on
f(4)=plot((0:H)', QIRF_point_shock(:,[j95])-QIRF_point(:,[j95]), 'b-*','LineWidth',2);
hold on
f(5)=plot((0:H)', QIRF_point_shock(:,[j99])-QIRF_point(:,[j99]), 'p-','LineWidth',2,'Color','b');
hold off
legend([f(1), f(2), f(3), f(4), f(5)],[{'1%'},{'5%'},{' 50%'},{'95%'},{'99%'}], 'Location', 'southeast');
legend boxoff
ylim([-1 1])
grid on
title('Difference', 'FontSize', 14)
xlabel('h', 'FontSize', 14)
ylabel('Inflation', 'FontSize', 14)
print(plt, fullfile(Fig, 'QIRFInfl03'),'-dpng');
clear('plt')
