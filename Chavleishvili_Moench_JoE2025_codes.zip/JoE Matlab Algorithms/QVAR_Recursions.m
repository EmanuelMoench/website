function Y_H=QVAR_Recursions(Y,b_hat,N,p,T,Shock,Iter)
rng(Iter)
K=size(Y,2);
W=Y(T,:)';
if p>1
   for lag=2:p
       W=[W;Y(T-lag+1,:)'];
   end
end
I=QVAR_Index(K,N);

[omega, A_0, A_1]=QVAR_Companion_Form(b_hat,p,K,I);
X=W;

W(1)=Shock;

for k=1+1:K
    W(k)=omega(k)+A_1(k,:)*X+A_0(k,1:k-1)*W(1:k-1);
end
Y_H=W(1:K); 
end
