function [Y_IP, Y_Infl]=VAR_Bootstrap(Y,b_hat_VAR,H,p,T,B,Eps,date)
K=size(Y,2);
[omega,A_0,A_1]=VAR_Companion_Form(b_hat_VAR,p,K);
phi=(eye(size(A_0))-A_0)\omega;
Phi=(eye(size(A_0))-A_0)\A_1;

Y_IP=zeros(H,B);
Y_Infl=zeros(H,B);
for b=1:B
    rng(b);
    index=0;
    while sum(sum(index==0)')~=0
          index=round(rand((T-p),K)*(T-p));
    end
    Y_b=zeros(T,K);
    Y_b(1:p,:)=Y(1:p,:);
    W=Y(p,:)';
    if p>1
       for lag=2:p
           W=[W;Y(p-lag+1,:)'];
       end
    end
    u=Eps(index);
    U=zeros(size(W));
    J=0;
    for t=p+1:T
        J=J+1;
        U(1:K,:)=u(J,:)';
        W=phi+Phi*W+(eye(size(A_0))-A_0)\U;
        Y_b(t,:)=W(1:K);
    end
    for eq=1:K
        [b_hat_VAR{1,eq},~,~,~] = VAR(Y_b,p,eq);
    end
    Y_forc=VAR_Forecasts(Y,b_hat_VAR,H,p,find(year(date) == 2005 & month(date) ==  8));
    Y_IP(:,b)=Y_forc(:,3);
    Y_Infl(:,b)=Y_forc(:,4);
end
end