%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Repetitive disaster shocks%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Read the data file and transform variables
clear
clc
close all
sheet=1;
xlsfilename = 'DisasterMacroData.xls';
[X, TEXT]   = xlsread(xlsfilename,sheet);
Headers     = TEXT(1,2:end);

Variables = {'CD' 'ICSA' 'IP_growth' 'CPI_growth'  'Uncertainty:h=1' 'FEDFUNDS'};
Y=[];
for i=1:size(Variables,2)
    Y=[Y,X(:,find(strcmp(Headers, Variables(i))==1))];
end
Y(:,1)=Y(:,1)/10^6;
Y(:,2)=Y(:,2)/10^6;

Y_Levels=[X(:,find(strcmp(Headers, 'IP_level')==1)),X(:,find(strcmp(Headers, 'CPI_level')==1))];

%% Generate dates
StartDate = datetime(1980,01,01);
EndDate   = datetime(2019,12,01);
date = (StartDate:calmonths(1):EndDate)';

%% Remove non-environmental disasters
s = find(year(date) == 2001 & month(date) ==  9);
Y(s,1)=0;

[T, K] = size(Y);
%% Folder for the figures
Fig = 'Figures';
%% QR algorithms
addpath('QR')
%% Specify and estimate the QVAR
p=6;
%% Equidistant quantile indices
U_Q=0.95;
L_Q=0.05;
L_Q_CD=0.25;
Quantile.Quant = L_Q:0.01:U_Q;
N = length(Quantile.Quant);
delta=(0.95-L_Q_CD)/(N-1);
Quantile.Quant_CD =L_Q_CD:delta:0.95;
%% Estimate the QVAR parameters equation-by-equation
b_hat=cell(N,K);
for q=1:N
    [b_hat{q,1},~,~,~] = QVAR(Y,Quantile.Quant_CD(q),p,1);
    for eq=2:K
        [b_hat{q,eq},~,~,~] = QVAR(Y,Quantile.Quant(q),p,eq);
    end
end
%% Synthesize sequential CD shocks and calibrate distributions
H=120;
n=10^4;

StartDate = datetime(2020,01,01);
EndDate   = datetime(2029,12,01);
date_H = (StartDate:calmonths(1):EndDate)';
%% Calculate scnearios
CD=Y(:,1);
CD_sorted_mild=CD(find(year(date) == 2000 & month(date) ==  1):end,1);

CD_sorted_moderate=CD(CD>prctile(CD,75));
CD_sorted_moderate=[CD_sorted_moderate;zeros(round(size(CD_sorted_moderate,1)/3),1)];

CD_sorted_severe=CD(CD>prctile(CD,90));
CD_sorted_severe=[CD_sorted_severe;zeros(round(size(CD_sorted_severe,1)/3),1)];
%% Simulate out-of-sample values
Y_Severe=cell(n,H);
Y_Mild=cell(n,H);
Y_Moderate=cell(n,H);

Simulated_Shocks_mild=zeros(H,n);
Simulated_Shocks_moderate=zeros(H,n);
Simulated_Shocks_severe=zeros(H,n);

for i=1:n
    rng(i);
    for h=1:H
        Simulated_Shocks_severe(h,i)=CD_sorted_severe(randsample(size(CD_sorted_severe,1),1));
        Simulated_Shocks_moderate(h,i)=CD_sorted_moderate(randsample(size(CD_sorted_moderate,1),1));
        Simulated_Shocks_mild(h,i)=CD_sorted_mild(randsample(size(CD_sorted_mild,1),1));
    end
end

plt=figure('Position', get(0, 'Screensize'));
subplot(1,2,1)
set(subplot(1,2,1), 'Position', [0.07, 0.25, 0.5, 0.5])
f(1)=plot(date,(Y(:,1)) , 'Color', 'b','LineWidth',1);
text(-0.08,2000,'\leftarrow Katrina', 'Color', 'm')
text(date(find(year(date) == 2000 & month(date) ==  8)),0.08,'Katrina \rightarrow', 'Color', 'r', 'FontSize', 14)
text(date(find(year(date) == 2008 & month(date) ==  1)),0.06,'Sandy \rightarrow', 'Color', 'r', 'FontSize', 14)
text(date(find(year(date) == 2007 & month(date) ==  1)),0.1,'Harvey/Irma/Maria \rightarrow', 'Color', 'r', 'FontSize', 14)
ylim([0 0.2])
ylabel('CD')
set(gca, 'box', 'off')
subplot(1,2,2)
set(subplot(1,2,2), 'Position', [0.57, 0.25, 0.2, 0.5])
f(2)=plot(date_H,Simulated_Shocks_mild(:,3), 'k-','LineWidth',1);
hold on
f(3)=plot(date_H,Simulated_Shocks_moderate(:,3), 'b-','LineWidth',1);
hold on
f(4)=plot(date_H,Simulated_Shocks_severe(:,3), 'r-','LineWidth',1);
hold off
ylim([0 0.2])
xticks(datetime(' 01-Jan-2020') : calyears(4) : datetime('01-Dec-2029'))
hold off
ax1 = gca;
set(gca, 'box', 'off')
set(gca, 'YTick', []);
ax1.YAxis.Visible = 'off'; 
xl = xlim(); 
line([xl(1), xl(1)], ylim, 'color', 'k', 'LineStyle', '--');
legend([f(2), f(3), f(4)],{'Mild','Moderate','Severe'}, 'Location', 'northwest');
legend boxoff
print(plt, fullfile(Fig, 'ScenarioCDSinthetic'),'-dpng');
clear('plt')

%% KDE Plots
 % S
Annual_CD_mild=zeros(H-11,n);
Annual_CD_moderate=zeros(H-11,n);
Annual_CD_severe=zeros(H-11,n);
Annual_CD_Insample=zeros(T-11,1);

for i=1:n
J=0;
    for h=12:H
        J=J+1;
        Annual_CD_mild(J,i)=sum(Simulated_Shocks_mild(J:h,i));
        Annual_CD_moderate(J,i)=sum(Simulated_Shocks_moderate(J:h,i));
        Annual_CD_severe(J,i)=sum(Simulated_Shocks_severe(J:h,i));
    end
end
J=0;
for t=12:T
    J=J+1;
    Annual_CD_Insample(J)=sum(CD(J:t));
end

mu=mean(Annual_CD_Insample);
mu_counterfactual_mild=mean(mean(Annual_CD_mild));
mu_counterfactual_moderate=mean(mean(Annual_CD_moderate));
mu_counterfactual_severe=mean(mean(Annual_CD_severe));

for i=1:n
    pts = 0:0.01:0.7;
    [f_mild(i,:),xi_mild] = ksdensity(Annual_CD_mild(:,i),pts);
    [f_moderate(i,:),xi_moderate] = ksdensity(Annual_CD_moderate(:,i),pts);
    [f_severe(i,:),xi_severe] = ksdensity(Annual_CD_severe(:,i),pts);
end


plt=figure;
f(1)=plot(xi_mild,mean(f_mild,1),'-k','LineWidth',2);
f(4)=xline(mu,'--g','LineWidth',2);
xline(mu_counterfactual_mild,'--k','LineWidth',2)
hold on
f(2)=plot(xi_moderate,mean(f_moderate,1),'-b','LineWidth',2);
xline(mu_counterfactual_moderate,'--b','LineWidth',2)
hold on
f(3)=plot(xi_severe,mean(f_severe,1),'-r','LineWidth',2);
xline(mu_counterfactual_severe,'--r','LineWidth',2)
legend([f(1),f(2),f(3),f(4)],{'Mild','Moderate','Severe','Empirical mean'})
print(plt, fullfile(Fig, 'ScenarioJointKernel'),'-dpng');
clear('plt')

