%%%%%%%%%%%%%%%%%%%%
%MIRFs for the QVAR%
%%%%%%%%%%%%%%%%%%%%
%% Read the data file and transform variables
clear
clc
close all
sheet=1;
xlsfilename = 'DisasterMacroDataACI.xlsx';
[X, TEXT]   = xlsread(xlsfilename,sheet);
Headers     = TEXT(1,2:end);

Variables = {'ACI1' 'ICSA' 'IP_growth' 'CPI_growth'  'Uncertainty:h=1' 'FEDFUNDS'};
Y=[];
for i=1:size(Variables,2)
    Y=[Y,X(:,find(strcmp(Headers, Variables(i))==1))];
end
Y(:,2)=Y(:,2)/10^6;

% Generate dates
StartDate = datetime(1980,01,01);
EndDate   = datetime(2019,12,01);
date = (StartDate:calmonths(1):EndDate)';



[T, K] = size(Y);

Headers = {'ACI' 'Claims' 'Growth' 'Inflation'  'Uncertainty' 'Policy rate'};

%Folder for the figures
Fig = 'Figures';


% Folder for the figures
Fig = 'Figures';
plt=figure('Position', get(0, 'Screensize'));
f=plot(date,Y(:,1),'r-','LineWidth',2);
datetick('x', 'yyyy')
axis tight; box on;
title('The Actuaries Climate Index (ACI)','fontsize',14)
print(plt, fullfile(Fig, 'MayFigure00.png'),'-dpng');
clear('plt')

% QR algorithms
addpath('QR')
%% Specify and estimate the QVAR
p=6;
% Specify an equidistant grid of the quantile indices
U_Q=0.95;
L_Q=0.05;
L_Q_CD=0.05;
U_Q_CD=0.95;
Quantile.Quant = L_Q:0.01:U_Q;
N = length(Quantile.Quant);
delta=(U_Q_CD-L_Q_CD)/(N-1);
Quantile.Quant_CD =L_Q_CD:delta:U_Q_CD;

% Estimate the QVAR parameters equation-by-equation
b_hat=cell(N,K);
for q=1:N
    [b_hat{q,1},~,~,~] = QVAR(Y,Quantile.Quant_CD(q),p,1);
    for eq=2:K
        [b_hat{q,eq},~,~,~] = QVAR(Y,Quantile.Quant(q),p,eq);
    end
end
%% Specify and construct MIRFs
% Define the CD shocks 
sigma = std(Y);
Shock = zeros(K,1);
Shock(1,1) = 4*sigma(1);

QIRF=cell(1,2);
IRF=cell(1,2);

H=12;

n=10^(5);
psai=2/5;
K=5;

n_sub=fix(K*n^(psai));
B=10000;

% Simulate out-of-sample values and calculate QIRFs
Y_H = QVAR_Distribution_Forecasts(Y,b_hat,N,H,p,T,n);
Y_H_shock =Cond_QVAR_Distribution_Forecasts(Y,b_hat,N,H,p,T,n,Shock);

%% Calculate MIRFs for the IP
Y_sub=cell(n_sub,1);
Y_sub_shock=cell(n_sub,1);
q_shock =cell(1,B);
q =cell(1,B);

for j=1:B
        Draw=round(rand(n_sub,1)*n);
        Draw(Draw<= 0) = 1;
        Draw_shock=round(rand(n_sub,1)*n);
        Draw_shock(Draw_shock<= 0) = 1;
    for i=1:n_sub
        Y_sub{i}=Y_H{Draw(i)};
        Y_sub_shock{i}=Y_H_shock{Draw_shock(i)};
    end
    for h=1:H
        q{j}(h,:)=[std(cellfun(@(c)c(h,3),Y_sub)),mean(cellfun(@(c)c(h,3),Y_sub)),skewness(cellfun(@(c)c(h,3),Y_sub)),kurtosis(cellfun(@(c)c(h,3),Y_sub))];
        q_shock{j}(h,:)=[std(cellfun(@(c)c(h,3),Y_sub_shock)),mean(cellfun(@(c)c(h,3),Y_sub_shock)),skewness(cellfun(@(c)c(h,3),Y_sub_shock)),kurtosis(cellfun(@(c)c(h,3),Y_sub_shock))];
    end
    QIRF{j}=q_shock{j}-q{j};
    sprintf('Subsampling iteration %d', j)
end
q=zeros(H,4);
q_shock =zeros(H,4);
for h=1:H
    q(h,:)=[std(cellfun(@(c)c(h,3),Y_H)),mean(cellfun(@(c)c(h,3),Y_H)),skewness(cellfun(@(c)c(h,3),Y_H)),kurtosis(cellfun(@(c)c(h,3),Y_H))];
    q_shock(h,:)=[std(cellfun(@(c)c(h,3),Y_H_shock)),mean(cellfun(@(c)c(h,3),Y_H_shock)),skewness(cellfun(@(c)c(h,3),Y_H_shock)),kurtosis(cellfun(@(c)c(h,3),Y_H_shock))];
end
QIRF_point=q_shock-q;
sigma_hat=cell(1,4);
alpha=10;

for h=1:H
    for j=1:4
        sigma_hat{j}(h,1)=prctile(cellfun(@(c)c(h,j),QIRF)-QIRF_point(h,j),alpha/2);
        sigma_hat{j}(h,2)=prctile(cellfun(@(c)c(h,j),QIRF)-QIRF_point(h,j),100-alpha/2);
    end
end

% Plots
plt=figure;
f=plot((1:H)',QIRF_point(:,1) , '--','LineWidth',2,'Color','b');
hold on
plot((1:H)', QIRF_point(:,1)-sigma_hat{1},'b:','LineWidth',1.5);
hold on
plot(1:h,zeros(h,1),'r-','LineWidth',0.5);
hold off
xlabel('h')
grid on
title('Moment IRFs, Industrial production', 'FontSize', 14)
legend(f,{'Standard deviation'}, 'Location', 'northeast');
legend boxoff
print(plt, fullfile(Fig, 'ACIStdIp'),'-dpng');
clear('plt')

plt=figure;
f=plot((1:H)',QIRF_point(:,2) , '--','LineWidth',2,'Color','b');
hold on
plot((1:H)', QIRF_point(:,2)-sigma_hat{2},'b:','LineWidth',1.5);
hold on
plot(1:h,zeros(h,1),'r-','LineWidth',0.5);
hold off
xlabel('h')
title('Moment IRFs, Industrial production', 'FontSize', 14)
grid on
legend(f,{'Mean'}, 'Location', 'northeast');
legend boxoff
print(plt, fullfile(Fig, 'ACIMeanIp.png'),'-dpng');
clear('plt')

plt=figure;
f=plot((1:H)',QIRF_point(:,3) , '--','LineWidth',2,'Color','b');
hold on
plot((1:H)', QIRF_point(:,3)-sigma_hat{3},'b:','LineWidth',1.5);
hold on
plot(1:h,zeros(h,1),'r-','LineWidth',0.5);
hold off
xlabel('h')
grid on
legend(f,{'Skewness'}, 'Location', 'northeast');
title('Moment IRFs, Industrial production', 'FontSize', 14)
legend boxoff
print(plt, fullfile(Fig, 'ACISkewnessIp.png'),'-dpng');
clear('plt')

plt=figure;
f=plot((1:H)',QIRF_point(:,4) , '--','LineWidth',2,'Color','b');
hold on
plot((1:H)', QIRF_point(:,4)-sigma_hat{4},'b:','LineWidth',1.5);
hold on
plot(1:h,zeros(h,1),'r-','LineWidth',0.5);
hold off
xlabel('h')
grid on
legend(f,{'Kurtosis'}, 'Location', 'northeast');
title('Moment IRFs, Industrial production', 'FontSize', 14)
legend boxoff
print(plt, fullfile(Fig, 'ACIKurtosisIp.png'),'-dpng');
clear('plt')
%% Calculate MIRFs for the Inflation
Y_sub=cell(n_sub,1);
Y_sub_shock=cell(n_sub,1);
q_shock =cell(1,B);
q =cell(1,B);

for j=1:B
        Draw=round(rand(n_sub,1)*n);
        Draw(Draw<= 0) = 1;
        Draw_shock=round(rand(n_sub,1)*n);
        Draw_shock(Draw_shock<= 0) = 1;
    for i=1:n_sub
        Y_sub{i}=Y_H{Draw(i)};
        Y_sub_shock{i}=Y_H_shock{Draw_shock(i)};
    end
    for h=1:H
        q{j}(h,:)=[std(cellfun(@(c)c(h,4),Y_sub)),mean(cellfun(@(c)c(h,4),Y_sub)),skewness(cellfun(@(c)c(h,4),Y_sub)),kurtosis(cellfun(@(c)c(h,4),Y_sub))];
        q_shock{j}(h,:)=[std(cellfun(@(c)c(h,4),Y_sub_shock)),mean(cellfun(@(c)c(h,4),Y_sub_shock)),skewness(cellfun(@(c)c(h,4),Y_sub_shock)),kurtosis(cellfun(@(c)c(h,4),Y_sub_shock))];
    end
    QIRF{j}=q_shock{j}-q{j};
    sprintf('Subsampling iteration %d', j)
end
q=zeros(H,4);
q_shock =zeros(H,4);
for h=1:H
    q(h,:)=[std(cellfun(@(c)c(h,4),Y_H)),mean(cellfun(@(c)c(h,4),Y_H)),skewness(cellfun(@(c)c(h,4),Y_H)),kurtosis(cellfun(@(c)c(h,4),Y_H))];
    q_shock(h,:)=[std(cellfun(@(c)c(h,4),Y_H_shock)),mean(cellfun(@(c)c(h,4),Y_H_shock)),skewness(cellfun(@(c)c(h,4),Y_H_shock)),kurtosis(cellfun(@(c)c(h,4),Y_H_shock))];
end
QIRF_point=q_shock-q;
sigma_hat=cell(1,4);
alpha=10;

for h=1:H
    for j=1:4
        sigma_hat{j}(h,1)=prctile(cellfun(@(c)c(h,j),QIRF)-QIRF_point(h,j),alpha/2);
        sigma_hat{j}(h,2)=prctile(cellfun(@(c)c(h,j),QIRF)-QIRF_point(h,j),100-alpha/2);
    end
end

% Plots
plt=figure;
f=plot((1:H)',QIRF_point(:,1) , '--','LineWidth',2,'Color','b');
hold on
plot((1:H)', QIRF_point(:,1)-sigma_hat{1},'b:','LineWidth',1.5);
hold on
plot(1:h,zeros(h,1),'r-','LineWidth',0.5);
hold off
xlabel('h')
grid on
title('Moment IRFs, Inflation', 'FontSize', 14)
legend(f,{'Standard deviation'}, 'Location', 'northeast');
legend boxoff
print(plt, fullfile(Fig, 'ACIStdInfl'),'-dpng');
clear('plt')

plt=figure;
f=plot((1:H)',QIRF_point(:,2) , '--','LineWidth',2,'Color','b');
hold on
plot((1:H)', QIRF_point(:,2)-sigma_hat{2},'b:','LineWidth',1.5);
hold on
plot(1:h,zeros(h,1),'r-','LineWidth',0.5);
hold off
xlabel('h')
title('Moment IRFs, Inflation', 'FontSize', 14)
grid on
legend(f,{'Mean'}, 'Location', 'northeast');
legend boxoff
print(plt, fullfile(Fig, 'ACIMeanInfl.png'),'-dpng');
clear('plt')

plt=figure;
f=plot((1:H)',QIRF_point(:,3) , '--','LineWidth',2,'Color','b');
hold on
plot((1:H)', QIRF_point(:,3)-sigma_hat{3},'b:','LineWidth',1.5);
hold on
plot(1:h,zeros(h,1),'r-','LineWidth',0.5);
hold off
xlabel('h')
grid on
legend(f,{'Skewness'}, 'Location', 'northeast');
title('Moment IRFs, Inflation', 'FontSize', 14)
legend boxoff
print(plt, fullfile(Fig, 'ACISkewnessInfl.png'),'-dpng');
clear('plt')

plt=figure;
f=plot((1:H)',QIRF_point(:,4) , '--','LineWidth',2,'Color','b');
hold on
plot((1:H)', QIRF_point(:,4)-sigma_hat{4},'b:','LineWidth',1.5);
hold on
plot(1:h,zeros(h,1),'r-','LineWidth',0.5);
hold off
xlabel('h')
grid on
legend(f,{'Kurtosis'}, 'Location', 'northeast');
title('Moment IRFs, Inflation', 'FontSize', 14)
legend boxoff
print(plt, fullfile(Fig, 'ACIKurtosisInfl.png'),'-dpng');
clear('plt')