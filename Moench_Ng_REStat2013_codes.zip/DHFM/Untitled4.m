

gmat = zeros(1000,227,5);

for i=1:1000
gmat(i,:,:) = cell2mat(G{i});
end