gmat = zeros(1000,227,5);

for i=1:1000
gmat(i,:,:) = cell2mat(G{i});
end
g_emp = gmat(:,:,2);
g_emp_mean = mean(g_emp,1);
g_house = gmat(:,:,4);
g_house_mean = mean(g_house,1);

g_ip = gmat(:,:,1);
g_ip_mean = mean(g_ip,1);

g_con = gmat(:,:,3);
g_con_mean = mean(g_con,1);

g_survey = gmat(:,:,5);
g_survey_mean = mean(g_survey,1);


fmat = zeros(1000,227);
for i = 1:1000
fmat(i,:) = F{i};    
end

f_mean = mean(fmat,1);
t = (1992+4/12):(1/12):(2011+2/12);
 plot(t,f_mean,'k')
hold on
plot(t,g_emp_mean,'b')
hold on
 plot(t,g_house_mean,'g')
hold on
% plot(t,g_ip_mean,'y')
% hold on
% plot(t,g_con_mean,'m')
% hold on
% plot(t,g_survey_mean,'r')
% hold on
 plot(t,-FX_pc','y')